<?php
require 'pdfcrowd.php';

try
{
    // create the API client instance
    $client = new \Pdfcrowd\HtmlToPdfClient("monwabisityobeka", "b874b3849b77accc36925205729ff0e8");

    // run the conversion and write the result to a file
    $client->convertFileToFile("../uni.html", "MyLayout.pdf");
}
catch(\Pdfcrowd\Error $why)
{
    // report the error
    error_log("Pdfcrowd Error: {$why}\n");

    // handle the exception here or rethrow and handle it at a higher level
    throw $why;
}

?>