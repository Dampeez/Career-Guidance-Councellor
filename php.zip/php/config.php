<?php 
    session_start();
    require_once "GoogleAPI/vendor/autoload.php";
    $gClient = new Google_Client();
    $gClient->setClientId("129017647119-qackikmt6fldbe6gmt2qae8q30hgv1us.apps.googleusercontent.com");
    $gClient->setClientSecret("zEsUn5i1521EH_O7i7ISfF_Z");
    $gClient->setApplicationName("Career Path Selection Sign Up");
    $gClient->setRedirectUri("http://localhost/CPSFULL/php/g-callback.php");
    $gClient->addScope(Google_Service_People::PLUS_LOGIN);
    //$gClient->addScope("https://www.googleapis.com/auth/plus.login" "https://www.googleapis.com/auth/userinfo.email");
    //Google_Service_Drive::DRIVE
?>