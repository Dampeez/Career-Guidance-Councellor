<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php
	
	include_once 'connection.php';

	$email= $_GET['email'];
	$code= $_GET['code'];

	$sql= mysql_query("SELECT * FROM users WHERE email ='$email'");
	while ($row = mysql_fetch_assoc($sql)) 
	{
		$db_code = $row['confirm-code'];
	}

	if ($code == $db_code) {

		mysql_query("UPDATE users SET confirmed='1'");	
		mysql_query("UPDATE users SET confirm-code='0'");
		echo "Your email has been confirmed. You can login.";
	}
	else{
		echo "Email address and code don't match";
	}



?>

</body>
</html>