<?php
	//include'connection.php';
	if(isset($_POST['button'])) 
	{	
		include_once 'connection.php';

		$name = $_POST['name'];
		$surname = $_POST['surname'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$confirm_password = $_POST['confirm_password'];

		//error handlers
		//check for empty fields
		if (empty($name) || empty($surname) || empty($phone) || empty($email) || empty($password) || empty($confirm_password)) {
			header("Location: ../../login/sign.php?signup=empty");
			exit(); //stops script from running even if something exists after this	
		} else {
			//check input characters are valid
			if (!preg_match("/^[a-zA-Z]*$/", $name)  || !preg_match("/^[a-zA-Z]*$/", $surname)) {  //looking at all letters we allow
				echo '<script type="text/javascript">'; 
				echo 'alert("Name or surname is invalid.");'; 
				echo 'window.location.href = "../../login/sign.php?signin=error";';
				echo '</script>';
				exit();
			} else {
					//check if email is valid
					if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
					echo '<script type="text/javascript">'; 
					echo 'alert(Email address is invalid.");'; 
					echo 'window.location.href = "../../login/sign.php?signin=error";';
					echo '</script>';
					exit();

				} else {
					$sql = "SELECT * FROM users where email = '$email'";
					$result = mysqli_query($db, $sql);
					$resultCheck = mysqli_num_rows($result);
					if($resultCheck >0) {

					echo '<script type="text/javascript">'; 
					echo 'alert("Email address is already taken.");'; 
					echo 'window.location.href = "../../login/sign.php?signin=error";';
					echo '</script>';
					exit();

					} else {

						if ($_POST["password"] === $_POST["confirm_password"]) 
						{			
							//echo '<script type="text/javascript">'; 
							//echo 'alert("Your account is almost ready. Verify your email address.");'; 
							//echo 'window.location.href = "../../login/sign.php?signin=inactivate";';
							//echo '</script>';
							
									//echo "Password match"." <br>";
							 $res = $db->query("INSERT INTO users (name, surname, phone, email, password, confirm_password) VALUES ('$name', '$surname', '$phone', '$email', '$password', '$confirm_password')"); 

    if ($res) 
	{
		
										
				echo '<script type="text/javascript">'; 
				echo 'alert("Welcome to Career Path Guidance. Lets get started.");'; 
				echo 'window.location.href = "../../uindex.php";';
				echo '</script>'; //"You have successfully added a new employee. Hit link below to view all employee information<br><br>
				//<tr>
				//<td>
				//<a href='nread.php'>Staff Roster</a>
				//</td>
				//</tr>";	

	}
	else{

		echo "Data not inserted";
		echo mysqli_error($db);
	}
									
										//if ($sql) 
										//{	echo "You have successfully registered. Hit link below to login:<br><br>
												//<tr>
												//<td>
												//<a href='../login.php'>Login</a>
												//</td>
												//</tr>";		
										//}
							
										
										//header("Location: ../register.php?signup=success");
										//exit();
									
							
						}
						else{
							echo "Passwords don't match. Please retype password.";
						}


					}
			    }
			}
		
		}
	} else {

		header("Location: ../../login/sign.php?worse");
		exit(); //stops script from running even if something exists after this
	}
?>