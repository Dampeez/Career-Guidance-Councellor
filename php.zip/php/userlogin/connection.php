<?php

	$db = new mysqli('154.0.170.55:3306','onump_cpguidance','*8z44Qlh','onumpqxe_cpg');

	if(!$db)
	{

			die("Connection failed: ". mysqli_connect_error());
	}
	//echo "Connected Successfully"

?>