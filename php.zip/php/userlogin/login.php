<?php 

include_once('connection.php');



$username = $_POST['email'];
$password = $_POST['password'];

$res = $mysqli->query("SELECT * FROM users WHERE email = '".$email."' AND password = '".$password."'");


if ($res->num_rows == 1) 
{	
	
	header("Location: ../../index.php");
}	
else{

	echo "Username or Password is invalid";
}
 
 
?>   