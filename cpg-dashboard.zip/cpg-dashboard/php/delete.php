<?php
$id = $_GET["id"];
include "connect.php";
?>
<div class="mov-container">
<?php
	$re = $db->query("DELETE  FROM posts WHERE id = '$id'");
		

		if ($re) 	
		{	
				echo '<script type="text/javascript">'; 
				echo 'alert("The post was successfully deleted.");'; 
				echo 'window.location.href = "../forum.php";';
				echo '</script>'; //"You have successfully added

		}
		else
		{
			echo "Error";
		}
			

?>