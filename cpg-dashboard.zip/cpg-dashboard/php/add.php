<?php

	include "connection.php";

	if(isset($_POST["submit"])) 
	{
	
		$name = $_POST["name"];
		$surname = $_POST["surname"];
		$phone = $_POST["phone"];
		$email = $_POST["email"];
		$role = $_POST["role"];
		$password = $_POST["password"];
		$confirm_password = $_POST["confirm_password"];
	}
	else
	{

		echo "No data received";
	}
	
	$res = $db->query("INSERT INTO admins (name, surname, phone, email, role, password, confirm_password) VALUES ('$name','$surname', '$phone', '$email','$role', '$password', '$confirm_password')");
	if ($res) 
	{
		
										
				echo '<script type="text/javascript">'; 
				echo 'alert("Administrator is successfully added.");'; 
				echo 'window.location.href = "../view.php";';
				echo '</script>'; //"You have successfully added a new employee. Hit link below to view all employee information<br><br>
				//<tr>
				//<td>
				//<a href='nread.php'>Staff Roster</a>
				//</td>
				//</tr>";	

	}
	else{

		echo "Data not inserted";
		echo mysqli_error($db);
	}


?>