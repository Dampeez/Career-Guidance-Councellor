<?php

include('connect.php'); // Do Database Connection in this file (create a file namely connect.php inside MyProject Folder)
include('elogin.php');
extract($_POST);

//$UploadDoc = false;
//if(isset($_POST['UploadDoc'])){
   // $UploadDoc = $_POST['UploadDoc'];
 //} 
    //echo $UploadDoc;


if(isset($_POST["submit"])) 
{
	$subject = $_POST["subject"];
	$body = $_POST["body"];
	
	//$UploadDoc = $_POST['UploadDoc'];

}

$uname = $_SESSION['e_name'];
$surname = $_SESSION['e_surname'];
$propic = $_SESSION['e_image'];

$UploadedFileName=$_FILES['UploadDoc']['name'];

if($UploadedFileName!='')
{
  $upload_directory = "images/"; //This is the folder which you created just now
  $TargetPath=time().$UploadedFileName;
  if(move_uploaded_file($_FILES['UploadDoc']['tmp_name'], $upload_directory.$TargetPath)){ 
    $res = $db->query("INSERT INTO posts (subject, body, image, name, surname, propic) VALUES ('$subject', '$body', '$TargetPath', '$uname', '$surname', '$propic')"); 

    if ($res) 
	{
		
										
				echo '<script type="text/javascript">'; 
				echo 'alert("Your post was successfully uploaded");'; 
				echo 'window.location.href = "../forum.php";';
				echo '</script>'; //"You have successfully added a new employee. Hit link below to view all employee information<br><br>
				//<tr>
				//<td>
				//<a href='nread.php'>Staff Roster</a>
				//</td>
				//</tr>";	

	}
	else{

		echo "Data not inserted";
		echo mysqli_error($db);
	}
    // Write Mysql Query Here to insert this $QueryInsertFile   .                   
  }
 
  

}
elseif ($UploadedFileName=='') {
	$res = $db->query("INSERT INTO posts (subject, body, name, surname, propic) VALUES ('$subject', '$body', '$uname', '$surname', '$propic')"); 

    if ($res) 
	{
		
										
				echo '<script type="text/javascript">'; 
				echo 'alert("Your post was successfully uploaded.");'; 
				echo 'window.location.href = "../forum.php";';
				echo '</script>'; //"You have successfully added a new employee. Hit link below to view all employee information<br><br>
				//<tr>
				//<td>
				//<a href='nread.php'>Staff Roster</a>
				//</td>
				//</tr>";	

	}
	else{

		echo "Data not inserted";
		echo mysqli_error($db);
	}
}
  

?>