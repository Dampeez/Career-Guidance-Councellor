<?php
session_start();

	if(isset($_POST['button'])) 
	{	
		include_once 'connection.php';

		$email = mysqli_real_escape_string($db, $_POST['email']);
		$password = mysqli_real_escape_string($db, $_POST['password']);

		//error handlers
		//check for empty fields

		if (empty($email) || empty($password)) {
			header("Location: ../login.php?login=empty");
			exit();
		} else {	
				$sql = "SELECT * FROM admins where email = '$email' and password = '$password'";
				$result = mysqli_query($db, $sql);
				$resultCheck = mysqli_num_rows($result);
			if ($resultCheck < 1) {
				echo '<script type="text/javascript">'; 
				echo 'alert("Email address or password is invalid.");'; 
				echo 'window.location.href = "../login.php?login=error";';
				echo '</script>';
				//header("Location: ../../login/login.php?login=error");
				
				exit();
			} else {
				if ($row = mysqli_fetch_assoc($result)) {
					//log in user

					$_SESSION['e_id'] = $row['id'];
					$_SESSION['e_name'] = $row['name'];
					$_SESSION['e_surname'] = $row['surname'];
					$_SESSION['e_cell'] = $row['phone'];
					$_SESSION['e_email'] = $row['email'];
					$_SESSION['e_access'] = $row['role'];
					$_SESSION['e_pass'] = $row['password'];
					$_SESSION['e_conpass'] = $row['confirm_password'];
					$_SESSION['e_image'] = $row['image'];

						if ($_SESSION['e_access'] == "Developer") {
							header("Location: ../index.php?login=success");

						} else if ($_SESSION['e_access'] == "Admin") {

							header("Location: ../adindex.php?login=success");
							exit();
						}
						
						

					} else{
						echo "Login not working";
					}
	
				}
			}		
	} 
	//else {

		//header("Location: ../../index.php?login=error");
		//exit();
	//}


?>