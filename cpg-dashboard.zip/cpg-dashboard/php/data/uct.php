<?php

	include "../connection.php";

	if(isset($_POST["submit"])) 
	{
	
		$choice = $_POST["choice"];
		$field = $_POST["field"];
		$prog = $_POST["prog"];
		$duration = $_POST["duration"];
		$aps = $_POST["aps"];
		$faculty = $_POST["faculty"];

	}
	else
	{

		echo "No data received";
	}
	
	$res = $db->query("INSERT INTO uct (choice, field, prog_name, duration, aps, faculty) VALUES ('$choice','$field', '$prog', '$duration','$aps', '$faculty')");
	if ($res) 
	{
		
										
				echo '<script type="text/javascript">'; 
				echo 'alert("University of Cape Town course has successfully been added.");'; 
				echo 'window.location.href = "../../course.php";';
				echo '</script>'; //"You have successfully added a new employee. Hit link below to view all employee information<br><br>
				//<tr>
				//<td>
				//<a href='nread.php'>Staff Roster</a>
				//</td>
				//</tr>";	

	}
	else{

		echo "Data not inserted";
		echo mysqli_error($db);
	}


?>