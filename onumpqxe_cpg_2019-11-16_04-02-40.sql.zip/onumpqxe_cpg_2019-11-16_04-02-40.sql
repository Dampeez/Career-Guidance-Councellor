-- MySQL dump 10.13  Distrib 5.7.28, for Win64 (x86_64)
--
-- Host: 154.0.170.55    Database: onumpqxe_cpg
-- ------------------------------------------------------
-- Server version	5.6.33-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(150) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirm_password` varchar(50) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (101,'Monwabisi','Tyobeka','0799477260','tyobekamonwabisi@gmail.com','Developer','456mmtMMT','456mmtMMT','image1.jpg'),(102,'Damian','Moodley','0612345634','damianmoodley@gmail.com','Developer','567demDEM','567demDEM','image2.JPG'),(103,'Mohammed','Khan','0844321453','mokhan@gmail.com','Admin','789mfkMFK','789mfkMFK','image3.JPG'),(104,'Tebello','Moleofane','0864321245','tm@gmail.com','Admin','567tmmTMM','567tmmTMM',NULL);
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(100) NOT NULL,
  `body` varchar(50000) NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(10000) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `propic` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1022 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uct`
--

DROP TABLE IF EXISTS `uct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `choice` varchar(50) NOT NULL,
  `field` varchar(500) NOT NULL,
  `prog_name` varchar(1000) NOT NULL,
  `duration` varchar(10) NOT NULL,
  `aps` varchar(10) NOT NULL,
  `faculty` varchar(1000) NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=202 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uct`
--

LOCK TABLES `uct` WRITE;
/*!40000 ALTER TABLE `uct` DISABLE KEYS */;
INSERT INTO `uct` VALUES (201,'Choice 1','Engineering','Bachelor of Science in Engineering (BEng) in Chemical Engineering','4','42','Faculty of Engineering & the Built Environment','ucteng.jpg');
/*!40000 ALTER TABLE `uct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uj`
--

DROP TABLE IF EXISTS `uj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `choice` varchar(50) NOT NULL,
  `field` varchar(500) NOT NULL,
  `prog_name` varchar(1000) NOT NULL,
  `duration` varchar(10) NOT NULL,
  `aps` varchar(10) NOT NULL,
  `faculty` varchar(1000) NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=308 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uj`
--

LOCK TABLES `uj` WRITE;
/*!40000 ALTER TABLE `uj` DISABLE KEYS */;
INSERT INTO `uj` VALUES (301,'Choice 1','Engineering','Bachelor of Science in Engineering (BEng) in Civil Engineering','4','32','Faculty of Engineering and the Built Environment','ujeng.jpg'),(302,'Choice 1','Education','Bachelor of Education Degree in Foundation Phase Teaching ','4','26','Faculty of Education','ujedu.jpg'),(303,'Choice 2','Education','Bachelor of Education Degree in Intermediate Phase Teaching ','4','26','Faculty of Education','ujedu.jpg'),(304,'Choice 3','Education','Bachelor of Education Degree in  Senior Phase and Further Education and Training','4','26','Faculty of Education','ujedu.jpg'),(305,'Choice 1','Arts','Diploma in Jewellery Design','3','28','FADA',NULL),(306,'Choice 2','Arts','Diploma in Fashion Design','3','28','FADA',NULL),(307,'Choice 1','IT','Dip in Business IT','3','28','College of Business and Economics',NULL);
/*!40000 ALTER TABLE `uj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ukzn`
--

DROP TABLE IF EXISTS `ukzn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ukzn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `choice` varchar(50) NOT NULL,
  `field` varchar(500) NOT NULL,
  `prog_name` varchar(1000) NOT NULL,
  `duration` varchar(10) NOT NULL,
  `aps` varchar(10) NOT NULL,
  `faculty` varchar(1000) NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=503 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ukzn`
--

LOCK TABLES `ukzn` WRITE;
/*!40000 ALTER TABLE `ukzn` DISABLE KEYS */;
INSERT INTO `ukzn` VALUES (501,'Choice 1','Engineering','Bachelor of Science in Engineering (BEng) in Chemical Engineering','4','33','College of Agriculture, Engineering and Science','ukzneng.jpg'),(502,'Choice 2','Engineering','Bachelor of Science in Engineering (BEng) in Civil Engineering','4','28','College of Agriculture, Engineering and Science','ukzneng.jpg');
/*!40000 ALTER TABLE `ukzn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `up`
--

DROP TABLE IF EXISTS `up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `up` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `choice` varchar(50) NOT NULL,
  `field` varchar(500) NOT NULL,
  `prog_name` varchar(1000) NOT NULL,
  `duration` varchar(10) NOT NULL,
  `aps` varchar(10) NOT NULL,
  `faculty` varchar(1000) NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=403 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `up`
--

LOCK TABLES `up` WRITE;
/*!40000 ALTER TABLE `up` DISABLE KEYS */;
INSERT INTO `up` VALUES (401,'Choice 1','Engineering','Bachelor of Science in Engineering (BEng) in Chemical Engineering','4','35','Faculty of Engineering, Built Environment and Information Technology','upeng.jpg'),(402,'Choice 2','Engineering','Bachelor of Science in Engineering (BEng) in Civil Engineering','4','35','Faculty of Engineering, Built Environment and\r\nInformation Technology','upeng.jpg');
/*!40000 ALTER TABLE `up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `grade` varchar(11) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `high_school` varchar(200) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `confirm_password` varchar(50) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (101,'Themba','Nkosi','0783456789','thenkosi@gmail.com','11','Johannesburg','Alberton High School','123tyuTYU','123tyuTYU','1.jpg'),(102,'Reece','James','0612345654','reecej@gmail.com','11','Johannesburg','Benoni High School','567demDEM','567demDEM','2.jpg'),(103,'Lebo','Radebe','0751235678','lebor@hotmail.com','12','Johannesburg','Benoni High School','123tyuTYU','123tyuTYU','3.jpg'),(104,'Daniel','Levy','0861234567','dlvspurs@gmail.com','11','Pretoria','Willowridge High School','345dlvDLV','345dlvDLV','4.jpg'),(105,'Sharon','Mayfield','0765436754','shmayfield@gmail.com','12','Durban','Grosvenor Girls High School','123tyuTYU','123tyuTYU','5.jpg'),(106,'Mandy','Sinclair','0865234561','mandysinclair@gmail.com',NULL,NULL,NULL,'456DEMdem','456DEMdem',NULL),(107,'Fred','Gibson','0865234561','fredgibbo@gmail.com',NULL,NULL,NULL,'HEDhed456','HEDhed456',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wits`
--

DROP TABLE IF EXISTS `wits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `choice` varchar(50) NOT NULL,
  `field` varchar(500) NOT NULL,
  `prog_name` varchar(1000) NOT NULL,
  `duration` varchar(10) NOT NULL,
  `aps` varchar(10) NOT NULL,
  `faculty` varchar(1000) NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=603 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wits`
--

LOCK TABLES `wits` WRITE;
/*!40000 ALTER TABLE `wits` DISABLE KEYS */;
INSERT INTO `wits` VALUES (601,'Choice 1','Engineering','Bachelor of Science in Engineering (BEng) in Chemical Engineering','4','42','Faculty of Engineering & the Built Environment','witseng.jpg'),(602,'Choice 2','Engineering','Bachelor of Science in Engineering (BEng) in Civil Engineering','4','36','Faculty of Engineering & the Built Environment','witseng.jpg');
/*!40000 ALTER TABLE `wits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'onumpqxe_cpg'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-16  3:58:09
